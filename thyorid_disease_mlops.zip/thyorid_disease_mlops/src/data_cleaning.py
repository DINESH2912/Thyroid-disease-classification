import logging
from abc import ABC, abstractmethod
from typing import Union, Tuple
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder, StandardScaler
from imblearn.over_sampling import SMOTE

class DataStrategy(ABC):
    @abstractmethod
    def handle_data(self, data: pd.DataFrame) -> Union[pd.DataFrame, pd.Series]:
        pass

class DataCleaning(DataStrategy):
    def handle_data(self, data: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
        try:
            x = data.drop(["classes"], axis=1)
            y = data["classes"]

            x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=42)

            # Identify categorical columns and perform preprocessing steps
            categorical_columns = x_train.select_dtypes(exclude='number').columns
            ordinal_encoder = OrdinalEncoder()
            X_train_cat_encoded = pd.DataFrame(ordinal_encoder.fit_transform(x_train[categorical_columns]))
            X_train_cat_encoded.columns = categorical_columns

              # Transform the test set
            X_test_cat_encoded = pd.DataFrame(ordinal_encoder.fit_transform(x_test[categorical_columns]))
            X_test_cat_encoded.columns = categorical_columns
            
            # ... Other preprocessing steps ...
            label_encoder = LabelEncoder()
            y_train_cat_encoded = pd.DataFrame(label_encoder.fit_transform(y_train))
            y_test_cat_encoded = pd.DataFrame(label_encoder.transform(y_test))

            sc = StandardScaler()

            X_train_sc = pd.DataFrame(sc.fit_transform(x_train.select_dtypes(exclude='O')))
            X_test_sc = pd.DataFrame(sc.transform(x_test.select_dtypes(exclude='O')))

            X_train_sc.columns = x_train.select_dtypes(exclude='O').columns
            X_test_sc.columns = x_test.select_dtypes(exclude='O').columns

            X_train_final = pd.concat([X_train_sc, X_train_cat_encoded], axis=1)
            X_test_final = pd.concat([X_test_sc, X_test_cat_encoded], axis=1)

            # Use SMOTE for oversampling
            
            Y_train_resample_flat = y_train_cat_encoded.to_numpy().ravel()
            Y_test_resample_flat = y_test_cat_encoded.to_numpy().ravel()

            X_train_new = X_train_final[['age', 'sex', 'TSH', 'TT4', 'FTI', 'on_thyroxine', 'on_antithyroid_medication', 'goitre', 'hypopituitary', 'psych', 'T3_measured']]
            X_test_new = X_test_final[['age', 'sex', 'TSH', 'TT4', 'FTI', 'on_thyroxine', 'on_antithyroid_medication', 'goitre', 'hypopituitary', 'psych', 'T3_measured']]

            return X_train_new, X_test_new, Y_train_resample_flat, Y_test_resample_flat

        except Exception as e:
            logging.error("Error in data cleaning: {}".format(e))
            raise e
