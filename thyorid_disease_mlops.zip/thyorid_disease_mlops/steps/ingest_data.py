import logging
import pandas as pd
from zenml import step

class IngestData:
    def __init__(self, data_path: str):
        self.data_path = data_path

    def get_data(self) -> pd.DataFrame:
        logging.info(f"Ingesting data from {self.data_path}")
        return pd.read_csv(self.data_path)

@step
def ingest_df(data_path: str) -> pd.DataFrame:
    try:
        ingest_data = IngestData(data_path)
        df = ingest_data.get_data()

        # Assuming data is the variable you're trying to clean
        if df is not None:
            try:
                cleaned_data = df.copy()  # Make a copy to avoid modifying the original DataFrame
                # Continue with the rest of your data cleaning process using cleaned_data
                return cleaned_data
            except AttributeError as e:
                logging.error(f"Error in cleaning data: {e}")
                raise e  # Raise the error to indicate a problem with data cleaning
        else:
            logging.warning("Data is None, unable to perform data cleaning.")
            # Optionally, handle the case where data is None
            # This could involve setting a default value or skipping the cleaning step
            return pd.DataFrame()  # Return an empty DataFrame or handle it accordingly

    except Exception as e:
        logging.error(f"Error while ingesting or cleaning data: {e}")
        raise e
