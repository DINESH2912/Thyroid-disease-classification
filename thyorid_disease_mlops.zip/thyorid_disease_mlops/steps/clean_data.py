import logging
import pandas as pd
from zenml import step
from src.data_cleaning import DataCleaning
from typing_extensions import Annotated 
from typing import Tuple

@step
def clean_data1(df: pd.DataFrame) -> Tuple[
    Annotated[pd.DataFrame, "x_train"],
    Annotated[pd.DataFrame, "x_test"],
    Annotated[pd.DataFrame, "y_train"],
    Annotated[pd.DataFrame, "y_test"],
]:
    try:
        cleaning_strategy = DataCleaning()
        x_train, x_test, y_train, y_test = cleaning_strategy.handle_data(df)

        # Ensure that 'y_train' and 'y_test' are converted to DataFrames if they are Series
        y_train = pd.DataFrame(y_train)
        y_test = pd.DataFrame(y_test)
        
        return x_train, x_test, y_train, y_test

    except Exception as e:
        logging.error("Error in cleaning data: {}".format(e))
        raise e
