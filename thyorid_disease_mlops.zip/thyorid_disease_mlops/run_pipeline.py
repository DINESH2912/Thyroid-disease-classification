from pipelines.training_pipeline import train_pipeline

if __name__=="__main__":

    train_pipeline(data_path=r"C:\Users\DINESH\Dropbox\PC\Desktop\thyorid_disease_mlops\data\preprocessed_data.csv")

    